// 1. 引入wx-server-sdk（必须）
const cloud = require('wx-server-sdk')

// 2. 初始化cloud（必须）
cloud.init({
  env: 'cloud1-9ghg0fkfd7d6009d' // 你的云环境ID
})

// 3. 云函数主逻辑
exports.main = async (event, context) => {
  try {
    // 获取用户的openid
    const wxContext = cloud.getWXContext()
    return {
      code: 0,
      msg: '登录成功',
      data: {
        openid: wxContext.OPENID,
        appid: wxContext.APPID
      }
    }
  } catch (err) {
    return {
      code: -1,
      msg: '登录失败',
      data: null
    }
  }
}