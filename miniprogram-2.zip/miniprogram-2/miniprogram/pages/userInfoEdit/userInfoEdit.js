Page({
  data: {
    // 初始化数据字段（统一字段名，避免大小写/拼写不一致）
    nickname: '',
    community: '',
    phone: '',
    expectedGoods: '',
    userDetail: {} // 用于存储用户详情
  },

  onLoad(options) {
    // 兼容两种传参方式：直接加载/从我的页面传参
    if (options.userDetail) {
      // 从“我的”页面跳转时携带的用户信息
      const userDetail = JSON.parse(decodeURIComponent(options.userDetail || '{}'));
      this.setData({
        userDetail: userDetail,
        nickname: userDetail.nickname || '',
        community: userDetail.community || '',
        phone: userDetail.phone || '',
        expectedGoods: userDetail.expectedGoods || ''
      });
    } else {
      // 直接加载用户信息
      this.loadUserInfo();
    }
  },

  // 加载用户当前信息
  loadUserInfo() {
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }

    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    db.collection('user').where({ _openid: openid }).get({
      success: (res) => {
        if (res.data.length > 0) {
          const userData = res.data[0];
          // 同步数据到表单（确保字段名完全匹配）
          this.setData({
            userDetail: userData,
            nickname: userData.nickname || '',
            community: userData.community || '',
            phone: userData.phone || '',
            expectedGoods: userData.expectedGoods || ''
          });
        }
      },
      fail: (err) => {
        console.error('加载用户信息失败：', err);
        wx.showToast({ title: '加载信息失败', icon: 'none' });
      }
    });
  },

  // 输入框事件处理（修复e.detail.detail的错误）
  inputNickname(e) {
    this.setData({ nickname: e.detail.value });
  },
  inputPhone(e) {
    this.setData({ phone: e.detail.value });
  },
  inputCommunity(e) {
    this.setData({ community: e.detail.value });
  },
  inputExpectedGoods(e) {
    // 核心修复：把 e.detail.detail.value 改为 e.detail.value
    this.setData({ expectedGoods: e.detail.value });
  },

  // 保存个人信息（核心修复逻辑）
  saveUserInfo() {
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }

    // 表单校验：必须填写小区（修复文字错误）
    const { community } = this.data;
    if (!community || community.trim() === '') {
      wx.showToast({ title: '请填写所在小区', icon: 'none' });
      return;
    }

    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    // 构造要保存的用户数据（确保字段名和数据库一致）
    const userData = {
      nickname: this.data.nickname.trim(),
      community: this.data.community.trim(),
      phone: this.data.phone.trim(),
      expectedGoods: this.data.expectedGoods.trim(),
      updateTime: db.serverDate()
    };

    // 优先用已有ID更新（避免重复查询，提升效率）
    if (this.data.userDetail._id) {
      // 情况1：用户已有记录 → 直接更新
      db.collection('user').doc(this.data.userDetail._id).update({
        data: userData,
        success: () => {
          wx.showToast({ title: '保存成功', icon: 'success' });
          // 保存后返回并刷新“我的”页面
          this.refreshMinePage();
        },
        fail: (err) => {
          console.error('更新用户信息失败：', err);
          wx.showToast({ title: '保存失败', icon: 'none' });
        }
      });
    } else {
      // 情况2：用户无记录 → 新增（补充openid）
      db.collection('user').add({
        data: {
          ...userData,
          _openid: openid, // 必须绑定openid，否则“我的”页面查不到
          createTime: db.serverDate()
        },
        success: () => {
          wx.showToast({ title: '保存成功', icon: 'success' });
          // 保存后返回并刷新“我的”页面
          this.refreshMinePage();
        },
        fail: (err) => {
          console.error('新增用户信息失败：', err);
          wx.showToast({ title: '保存失败', icon: 'none' });
        }
      });
    }
  },

  // 核心：返回“我的”页面并强制刷新数据
  refreshMinePage() {
    setTimeout(() => {
      wx.navigateBack({
        delta: 1,
        success: () => {
          // 获取“我的”页面实例，重新加载用户信息
          const pages = getCurrentPages();
          const minePage = pages[pages.length - 2];
          if (minePage && minePage.loadUserDetail) {
            minePage.loadUserDetail(); // 强制刷新“我的”页面数据
          }
        }
      });
    }, 1000);
  },

  // 取消编辑（可选，方便用户返回）
  cancelEdit() {
    wx.navigateBack();
  }
});