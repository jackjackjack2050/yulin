Page({
  data: {
    goods: {}, // 物品详情
    isPublisher: false, // 是否是发布者本人
    userCommunity: '',   // 发布者的所在小区
    userExpectedGoods: '', // 发布者期望置换的物品（来自个人信息）
    isCollected: false // 新增：是否已收藏该物品
  },

  onLoad(options) {
    // 从首页/我的页面跳转时携带的物品ID
    const goodsId = options.id;
    const openid = wx.getStorageSync('openid');

    // 仅校验goodsId，移除openid的强制校验（允许未登录查看详情）
    if (!goodsId) {
      wx.showToast({ title: '参数错误', icon: 'none' });
      wx.navigateBack();
      return;
    }

    // 加载物品详情（传递openid，用于判断是否是发布者/加载收藏状态）
    this.loadGoodsDetail(goodsId, openid);
    // 仅当登录时加载收藏状态
    if (openid) {
      this.checkIsCollected(goodsId, openid);
    }
  },

  // 加载物品详情
  loadGoodsDetail(goodsId, openid) {
    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    db.collection('goods').doc(goodsId).get({
      success: (res) => {
        if (!res.data) {
          wx.showToast({ title: '物品不存在', icon: 'none' });
          wx.navigateBack();
          return;
        }

        // 未登录时，isPublisher默认false（不影响查看详情）
        this.setData({
          goods: res.data,
          isPublisher: openid ? (res.data._openid === openid) : false
        });

        // 加载发布者的个人信息（小区、期望置换）
        this.loadPublisherInfo(res.data._openid);
      },
      fail: () => {
        wx.showToast({ title: '加载失败', icon: 'none' });
        wx.navigateBack();
      }
    });
  },

  // 加载发布者的个人信息
  loadPublisherInfo(publisherOpenid) {
    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    // 查询用户信息时，_openid是系统字段，仅读取，合法
    db.collection('user').where({ _openid: publisherOpenid }).get({
      success: (res) => {
        if (res.data.length > 0) {
          this.setData({
            userCommunity: res.data[0].community || '未填写',
            userExpectedGoods: res.data[0].expectedGoods || '还没想好'
          });
        } else {
          this.setData({
            userCommunity: '未填写',
            userExpectedGoods: '还没想好'
          });
        }
      },
      fail: () => {
        console.log('加载发布者信息失败');
        this.setData({
          userCommunity: '未填写',
          userExpectedGoods: '还没想好'
        });
      }
    });
  },

  // 预览图片（支持缩放）
  previewImage(e) {
    const currentIndex = e.currentTarget.dataset.index;
    const imgList = this.data.goods.imgList || [];
    
    wx.previewImage({
      current: imgList[currentIndex],
      urls: imgList
    });
  },

  // 【核心修改】拨打电话联系发布者（新增登录跳转）
  callPublisher() {
    // 先校验登录状态
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      this.goToLogin('请先登录后联系发布者');
      return;
    }

    if (this.data.goods.isAnonymous) {
      wx.showToast({ title: '匿名发布无法拨打电话', icon: 'none' });
      return;
    }
    wx.makePhoneCall({
      phoneNumber: this.data.goods.phone,
      fail: () => {
        wx.showToast({ title: '拨打电话失败', icon: 'none' });
      }
    });
  },

  // 【核心修改】匿名时跳转微信聊天（新增登录跳转）
  chatPublisher() {
    // 先校验登录状态
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      this.goToLogin('请先登录后沟通');
      return;
    }

    wx.showToast({
      title: '已为你跳转微信沟通',
      icon: 'success'
    });
  },

  // 【核心修改】标记为已置换（新增登录跳转）
  markAsDone() {
    // 先校验登录状态
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      this.goToLogin('请先登录后操作');
      return;
    }

    // 仅发布者本人可操作
    if (!this.data.isPublisher) {
      wx.showToast({ title: '仅发布者可标记状态', icon: 'none' });
      return;
    }

    const goodsId = this.data.goods._id;
    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });

    wx.showModal({
      title: '确认标记',
      content: '是否标记该物品为已置换？',
      success: (res) => {
        if (res.confirm) {
          db.collection('goods').doc(goodsId).update({
            data: {
              status: '已置换',
              updateTime: db.serverDate()
            },
            success: () => {
              wx.showToast({ title: '标记成功' });
              this.setData({ 'goods.status': '已置换' });
            },
            fail: () => {
              wx.showToast({ title: '标记失败', icon: 'none' });
            }
          });
        }
      }
    });
  },

  // 【核心修改】标记为待置换（新增登录跳转）
  markAsPending() {
    // 先校验登录状态
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      this.goToLogin('请先登录后操作');
      return;
    }

    // 仅发布者本人可操作
    if (!this.data.isPublisher) {
      wx.showToast({ title: '仅发布者可标记状态', icon: 'none' });
      return;
    }

    const goodsId = this.data.goods._id;
    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });

    wx.showModal({
      title: '确认标记',
      content: '是否标记该物品为待置换？',
      success: (res) => {
        if (res.confirm) {
          db.collection('goods').doc(goodsId).update({
            data: {
              status: '待置换',
              updateTime: db.serverDate()
            },
            success: () => {
              wx.showToast({ title: '标记成功' });
              this.setData({ 'goods.status': '待置换' });
            },
            fail: () => {
              wx.showToast({ title: '标记失败', icon: 'none' });
            }
          });
        }
      }
    });
  },

  // 【核心修改】删除发布的物品（新增登录跳转）
  deleteGoods() {
    // 先校验登录状态
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      this.goToLogin('请先登录后操作');
      return;
    }

    // 仅发布者本人可操作
    if (!this.data.isPublisher) {
      wx.showToast({ title: '仅发布者可删除物品', icon: 'none' });
      return;
    }

    const goodsId = this.data.goods._id;
    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });

    wx.showModal({
      title: '确认删除',
      content: '是否永久删除该物品？删除后无法恢复！',
      confirmColor: '#ff3b30',
      success: (res) => {
        if (res.confirm) {
          db.collection('goods').doc(goodsId).remove({
            success: () => {
              wx.showToast({ title: '删除成功', icon: 'success' });
              wx.navigateBack();
            },
            fail: (err) => {
              console.error('删除失败：', err);
              wx.showToast({ title: '删除失败，请重试', icon: 'none' });
            }
          });
        }
      }
    });
  },

  // 【核心修改】跳转到该发布者的所有物品页面（新增登录跳转）
  goToUserGoods() {
    // 先校验登录状态
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      this.goToLogin('请先登录后查看');
      return;
    }

    const { _openid, publisher } = this.data.goods;
    if (!_openid) {
      wx.showToast({ title: '无法获取发布者信息', icon: 'none' });
      return;
    }
    wx.navigateTo({
      url: `/pages/userGoods/userGoods?publisherOpenid=${_openid}&publisherName=${publisher}`
    });
  },

  // ========== 收藏逻辑（修复：替换系统保留字段_openid为userId） ==========
  // 检查当前物品是否已被收藏
  checkIsCollected(goodsId, openid) {
    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    // 【修改1】将_openid改为自定义字段userId
    db.collection('collection')
      .where({
        userId: openid,    // 替换系统保留字段_openid
        goodsId: goodsId
      })
      .get({
        success: (res) => {
          this.setData({
            isCollected: res.data.length > 0
          });
        },
        fail: (err) => {
          console.error('检查收藏状态失败：', err);
          this.setData({ isCollected: false });
        }
      });
  },

  // 【核心修改】切换收藏/取消收藏（新增登录跳转）
  toggleCollect() {
    // 先校验登录状态
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      this.goToLogin('请先登录后收藏');
      return;
    }

    const goodsId = this.data.goods._id;
    const isCollected = this.data.isCollected;
    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });

    if (!goodsId) {
      wx.showToast({ title: '参数异常，无法收藏', icon: 'none' });
      return;
    }

    if (isCollected) {
      // 取消收藏
      // 【修改2】查询条件替换为userId
      db.collection('collection')
        .where({ userId: openid, goodsId: goodsId })
        .remove({
          success: () => {
            wx.showToast({ title: '取消收藏成功' });
            this.setData({ isCollected: false });
          },
          fail: (err) => {
            console.error('取消收藏失败：', err);
            wx.showToast({ title: '取消收藏失败', icon: 'none' });
          }
        });
    } else {
      // 收藏
      db.collection('collection').add({
        data: {
          // 【修改3】移除系统保留字段_openid，改用userId
          userId: openid,     // 自定义字段，替代_openid
          goodsId: goodsId,
          createTime: new Date()
        },
        success: () => {
          wx.showToast({ title: '收藏成功' });
          this.setData({ isCollected: true });
        },
        fail: (err) => {
          console.error('收藏失败：', err);
          wx.showToast({ title: '收藏失败', icon: 'none' });
        }
      });
    }
  },
  // ========== 收藏逻辑修复结束 ==========

  // ========== 分享功能核心逻辑（最终兼容版，无报错） ==========
  onShareTap() {
    const { goods } = this.data;
    // 1. 校验物品信息
    if (!goods._id) {
      wx.showToast({ title: '物品信息未加载完成，无法分享', icon: 'none' });
      return;
    }

    // 2. 通用方案：显示右上角分享菜单 + 友好提示（兼容所有环境）
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline'] // 支持分享给好友、朋友圈
    });

    // 提示用户操作（清晰易懂）
    wx.showToast({
      title: '请点击右上角 ··· 分享',
      icon: 'none',
      duration: 2500 // 显示2.5秒，足够用户看清
    });
  },

  // 保留：右上角分享的核心配置（小程序原生生命周期函数）
  onShareAppMessage() {
    const { goods } = this.data;
    return {
      title: `【置换好物】${goods.title}`,
      path: `/pages/detail/detail?id=${goods._id}`,
      imageUrl: goods.imgList && goods.imgList.length > 0 ? goods.imgList[0] : ''
    };
  },

  // 可选：支持朋友圈分享（如需）
  onShareTimeline() {
    const { goods } = this.data;
    return {
      title: `【置换好物】${goods.title}`,
      imageUrl: goods.imgList && goods.imgList.length > 0 ? goods.imgList[0] : ''
    };
  },
  // ========== 分享功能逻辑结束 ==========

  // 【新增通用方法】跳转到登录页（修复跳转方式+参数传递）
  goToLogin(tipText) {
    wx.showToast({
      title: tipText,
      icon: 'none',
      duration: 1500 // 提示显示1.5秒后跳转
    });

    // 延迟跳转，给用户看提示的时间
    setTimeout(() => {
      // 【关键修复1】tabBar页面必须用wx.switchTab跳转
      // 【关键修复2】用本地缓存传递来源和物品ID
      wx.setStorageSync('loginFromDetail', true);
      wx.setStorageSync('detailGoodsId', this.data.goods._id);

      wx.switchTab({
        url: '/pages/mine/mine' // 你的“我的”页面路径（确认是这个路径！）
      });
    }, 1500);
  }
});