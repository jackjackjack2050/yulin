Page({
  data: {
    imgList: [],          // 上传的图片列表
    title: '',            // 物品名称
    desc: '',             // 物品描述
    originalPrice: '',    // 原购买价格
    // 核心修改1：将“食品”改为“食品饮料”
    categories: ['家电/数码','家具/玩具','衣服/鞋子','食品饮料','其它'], // 类别选项
    selectedCategory: '请选择类别', // 选中的类别
    categoryIndex: 0,     // 新增：物品类别picker索引（解决下拉无响应）
    newLevels: ['全新', '9成新', '8成新', '7成新', '6成新', '5成新及以下'], // 新旧程度选项
    selectedNewLevel: '请选择新旧程度', // 选中的新旧程度
    newLevelIndex: 0,     // 新增：新旧程度picker索引（解决下拉无响应）
    intentions: ['置换', '赠送', '置换或赠送均可'], // 发布意向选项
    selectedIntention: '请选择意向', // 选中的意向
    intentionIndex: 0,    // 新增：发布意向picker索引（解决下拉无响应）
    publisher: '',        // 发布人（自动填充昵称）
    phone: '',            // 联系电话（自动填充手机号）
    isAnonymous: false,   // 是否匿名
    userCommunity: ''     // 存储用户小区信息
  },

  onLoad() {
    // 加载用户信息（包括小区）
    this.loadUserInfo();
  },

  // 加载用户信息（自动填充昵称/电话/小区）
  loadUserInfo() {
    const openid = wx.getStorageSync('openid');
    if (!openid) return;

    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    db.collection('user').where({
      _openid: openid
    }).get({
      success: (res) => {
        if (res.data.length > 0) {
          const userInfo = res.data[0];
          this.setData({
            publisher: userInfo.nickname || '',
            phone: userInfo.phone || '',
            userCommunity: userInfo.community || '' // 加载用户小区信息
          });
        }
      },
      fail: () => {
        console.log('加载用户信息失败，不自动填充');
      }
    });
  },

  // 选择图片
  chooseImg() {
    wx.chooseMedia({
      count: 3 - this.data.imgList.length,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      sizeType: ['compressed'],
      success: (res) => {
        const newImgList = res.tempFiles.map(file => file.tempFilePath);
        this.setData({
          imgList: this.data.imgList.concat(newImgList)
        });
      },
      fail: (err) => {
        wx.showToast({ title: '选择图片失败', icon: 'none' });
        console.log('选图失败原因：', err);
        if (err.errMsg.includes('chooseMedia:fail')) {
          this.chooseImageFallback();
        }
      }
    });
  },
  
  // 兼容旧版基础库的降级方法
  chooseImageFallback() {
    wx.chooseImage({
      count: 3 - this.data.imgList.length,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const fixedPaths = res.tempFilePaths.map(path => {
          if (path.startsWith('http://tmp')) {
            return path.replace('http://tmp', 'wxfile://tmp');
          }
          return path;
        });
        this.setData({
          imgList: this.data.imgList.concat(fixedPaths)
        });
      },
      fail: (err) => {
        wx.showToast({ title: '选择图片失败，请重试', icon: 'none' });
        console.log('降级选图失败：', err);
      }
    });
  },

  // 删除图片
  delImg(e) {
    const index = e.currentTarget.dataset.index;
    const imgList = [...this.data.imgList];
    imgList.splice(index, 1);
    this.setData({ imgList });
  },

  // 输入事件处理
  inputTitle(e) { this.setData({ title: e.detail.value.trim() }); },
  inputDesc(e) { this.setData({ desc: e.detail.value.trim() }); },
  inputOriginalPrice(e) { this.setData({ originalPrice: e.detail.value.trim() }); },
  
  // 核心修改2：修复picker下拉无响应，同步索引和选中值
  changeCategory(e) {
    const index = e.detail.value;
    this.setData({
      categoryIndex: index,
      selectedCategory: this.data.categories[index]
    });
  },
  changeNewLevel(e) {
    const index = e.detail.value;
    this.setData({
      newLevelIndex: index,
      selectedNewLevel: this.data.newLevels[index]
    });
  },
  changeIntention(e) {
    const index = e.detail.value;
    this.setData({
      intentionIndex: index,
      selectedIntention: this.data.intentions[index]
    });
  },
  
  inputPublisher(e) { this.setData({ publisher: e.detail.value.trim() }); },
  inputPhone(e) { this.setData({ phone: e.detail.value.trim() }); },
  toggleAnonymous(e) { this.setData({ isAnonymous: e.detail.value }); },

  // 发布闲置物品（核心修改：发布成功后跳转首页并刷新）
  publishGoods() {
    // 1. 登录状态校验
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      wx.showModal({
        title: '提示',
        content: '请先完成微信登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({ url: '/pages/login_new/login_new' });
          }
        }
      });
      return;
    }

    // 2. 表单必填项校验
    const { title, desc, originalPrice, selectedCategory, selectedNewLevel, 
            selectedIntention, publisher, phone, imgList, userCommunity } = this.data;
    
    if (!title) { wx.showToast({ title: '请输入物品名称', icon: 'none' }); return; }
    if (!desc) { wx.showToast({ title: '请输入物品描述', icon: 'none' }); return; }
    if (!originalPrice) { wx.showToast({ title: '请输入原购买价格', icon: 'none' }); return; }
    if (selectedCategory === '请选择类别') { wx.showToast({ title: '请选择物品类别', icon: 'none' }); return; }
    if (selectedNewLevel === '请选择新旧程度') { wx.showToast({ title: '请选择新旧程度', icon: 'none' }); return; }
    if (selectedIntention === '请选择意向') { wx.showToast({ title: '请选择发布意向', icon: 'none' }); return; }
    if (!userCommunity) { 
      wx.showModal({
        title: '提示',
        content: '请先完善个人信息中的所在小区',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({ url: '/pages/userInfoEdit/userInfoEdit' });
          }
        }
      });
      return;
    }
    if (!publisher) { wx.showToast({ title: '请输入发布人称呼', icon: 'none' }); return; }
    if (!phone) { wx.showToast({ title: '请输入联系电话', icon: 'none' }); return; }
    if (imgList.length === 0) { wx.showToast({ title: '请至少上传1张物品图片', icon: 'none' }); return; }

    // 3. 上传图片并保存数据
    wx.showLoading({ title: '发布中...' });

    const uploadPromises = [];
    for (let i = 0; i < imgList.length; i++) {
      const path = imgList[i];
      uploadPromises.push(
        wx.cloud.uploadFile({
          cloudPath: `goods/${Date.now()}-${i}.png`,
          filePath: path,
        })
      );
    }

    Promise.all(uploadPromises).then(uploadRes => {
      const imgUrls = uploadRes.map(res => res.fileID);
      const db = wx.cloud.database({
        env: 'cloud1-9ghg0fkfd7d6009d'
      });
      db.collection('goods').add({
        data: {
          title,
          desc,
          originalPrice: Number(originalPrice),
          category: selectedCategory,
          newLevel: selectedNewLevel,
          intention: selectedIntention,
          community: userCommunity,
          publisher: this.data.isAnonymous ? '匿名用户' : publisher,
          phone: this.data.isAnonymous ? '匿名发布，无公开电话' : phone,
          isAnonymous: this.data.isAnonymous,
          coverImg: imgUrls[0],
          imgList: imgUrls,
          status: '待置换',
          createTime: db.serverDate(),    
        },
        success: () => {
          wx.hideLoading();
          wx.showToast({ title: '发布成功！', icon: 'success' });
          
          // 核心修改：发布成功后跳转到首页（强制刷新）
          setTimeout(() => {
            wx.reLaunch({
              url: '/pages/index/index' // 直接重启并跳转到首页，确保数据刷新
            });
          }, 1500);
        },
        fail: (err) => {
          wx.hideLoading();
          wx.showToast({ title: '发布失败：' + err.errMsg, icon: 'none' });
          console.log('数据库失败原因：', err);
        }
      });
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '图片上传失败：' + err.errMsg, icon: 'none' });
      console.log('上传失败原因：', err);
    });
  }
});