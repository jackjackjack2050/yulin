Page({
  data: {
    goodsList: [], // 物品列表数据
    isLoading: true, // 加载状态
    hasMore: true, // 是否有更多数据
    page: 1, // 当前页码
    pageSize: 10, // 每页加载数量

    // 下拉筛选器数据（和发布页一致）
    categoryArray: ['全部类别', '家电/数码','家具/玩具','衣服/鞋子','食品饮料','其它'], // 【修改1】默认选项改为“全部类别”
    statusArray: ['全部状态', '待置换', '已置换'], // 【修改2】默认选项改为“全部状态”
    selectedCategory: '全部类别', // 【修改3】默认选中“全部类别”
    selectedStatus: '全部状态', // 【修改4】默认选中“全部状态”
    categoryIndex: 0,
    statusIndex: 0,
    searchKeyword: '' // 【新增】搜索关键词
  },

  // 页面加载/显示时都刷新数据
  onLoad() {
    this.loadGoodsList();
  },
  onShow() {
    // 每次进入首页都刷新最新数据（只刷新第一页）
    this.setData({
      page: 1,
      goodsList: [],
      hasMore: true
    });
    this.loadGoodsList();
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.setData({
      page: 1,
      goodsList: [],
      hasMore: true
    });
    this.loadGoodsList(() => {
      wx.stopPullDownRefresh(); // 停止下拉刷新
    });
  },

  // 上拉加载更多
  onReachBottom() {
    if (!this.data.hasMore || this.data.isLoading) return;
    this.setData({ page: this.data.page + 1 });
    this.loadGoodsList();
  },

  // 类别下拉选择器改变事件
  bindCategoryChange(e) {
    const index = e.detail.value;
    const selectedCategory = this.data.categoryArray[index];
    this.setData({
      categoryIndex: index,
      selectedCategory: selectedCategory,
      page: 1,
      goodsList: [],
      hasMore: true
    });
    this.loadGoodsList();
  },

  // 状态下拉选择器改变事件
  bindStatusChange(e) {
    const index = e.detail.value;
    const selectedStatus = this.data.statusArray[index];
    this.setData({
      statusIndex: index,
      selectedStatus: selectedStatus,
      page: 1,
      goodsList: [],
      hasMore: true
    });
    this.loadGoodsList();
  },

  // 【新增1】搜索输入框绑定事件：实时获取输入内容
  onSearchInput(e) {
    this.setData({
      searchKeyword: e.detail.value.trim() // 去除首尾空格
    });
  },

  // 【新增2】搜索按钮点击事件：执行搜索
  onSearch() {
    // 搜索时重置分页，清空现有列表
    this.setData({
      page: 1,
      goodsList: [],
      hasMore: true
    });
    this.loadGoodsList();
  },

  // 加载物品列表数据（带筛选+搜索条件）
  loadGoodsList(callback) {
    if (!this.data.hasMore) {
      if (callback) callback();
      return;
    }
    
    this.setData({ isLoading: true });
    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    const _ = db.command;

    // 构建筛选条件
    let whereCondition = {};
    // 类别筛选
    if (this.data.selectedCategory !== '全部类别') { // 【修改5】匹配新的默认值
      whereCondition.category = this.data.selectedCategory;
    }
    // 状态筛选
    if (this.data.selectedStatus !== '全部状态') { // 【修改6】匹配新的默认值
      whereCondition.status = this.data.selectedStatus;
    }
    // 【新增3】搜索条件：匹配标题或描述（模糊查询）
    if (this.data.searchKeyword) {
      whereCondition = _.and([
        whereCondition,
        _.or([
          { title: db.RegExp({ regexp: this.data.searchKeyword, options: 'i' }) }, // 标题模糊匹配，忽略大小写
          { desc: db.RegExp({ regexp: this.data.searchKeyword, options: 'i' }) } // 描述模糊匹配，忽略大小写
        ])
      ]);
    }

    // 分页查询物品列表（按发布时间倒序，最新的排在最前面）
    db.collection('goods')
      .where(whereCondition)
      .skip((this.data.page - 1) * this.data.pageSize)
      .limit(this.data.pageSize)
      .orderBy('createTime', 'desc') // 关键：按发布时间倒序，新发布的先显示
      .get({
        success: (res) => {
          const newGoodsList = res.data;
          const goodsList = this.data.page === 1 
            ? newGoodsList 
            : [...this.data.goodsList, ...newGoodsList];
          
          this.setData({
            goodsList,
            hasMore: newGoodsList.length === this.data.pageSize,
            isLoading: false
          });
          
          if (callback) callback();
        },
        fail: () => {
          wx.showToast({ title: '加载失败，请重试', icon: 'none' });
          this.setData({ isLoading: false });
          if (callback) callback();
        }
      });
  },

  // 跳转物品详情页
  goDetail(e) {
    const goodsId = e.currentTarget.dataset.id;
    if (!goodsId) return;
    wx.navigateTo({ url: `/pages/detail/detail?id=${goodsId}` });
  }
});