Page({
  data: {
    isLogin: false,
    userInfo: {
      nickName: '未设置昵称',
      avatarUrl: 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'
    },
    userDetail: {},
    myGoodsList: [],
    myCollectionList: [], // 新增：我的收藏列表
    canIUseGetUserProfile: true,
    // 【新增】记录从详情页跳转的标记和物品ID
    loginFromDetail: false,
    goodsId: ''
  },

  onLoad(options) {
    // 检测是否支持wx.getUserProfile
    if (!wx.getUserProfile) {
      this.setData({ canIUseGetUserProfile: false });
      wx.showToast({ title: '当前微信版本过低，无法使用该功能', icon: 'none' });
    }
  },

  onShow() {
    // 【核心修复】从本地缓存读取来源参数（tabBar页面onLoad无法接收URL参数）
    const loginFromDetail = wx.getStorageSync('loginFromDetail');
    const goodsId = wx.getStorageSync('detailGoodsId');
    if (loginFromDetail && goodsId) {
      this.setData({
        loginFromDetail: true,
        goodsId: goodsId
      });
      // 读取后清空缓存，避免残留
      wx.removeStorageSync('loginFromDetail');
      wx.removeStorageSync('detailGoodsId');
    }

    this.checkLogin();
  },

  // 检查登录状态并加载数据
  checkLogin() {
    const openid = wx.getStorageSync('openid');
    if (!openid) {
      this.setData({ 
        isLogin: false, 
        userDetail: {}, 
        myGoodsList: [],
        myCollectionList: [] // 新增：清空收藏列表
      });
      return;
    }

    this.setData({ isLogin: true });
    this.loadWxUserInfo();
    this.loadUserDetail();
    this.loadMyGoods();
    this.loadMyCollection(); // 新增：加载我的收藏
  },

  // 加载用户信息（优先读取自定义昵称）
  loadWxUserInfo() {
    const openid = wx.getStorageSync('openid');
    if (!openid) return;

    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    db.collection('user').where({ _openid: openid }).get({
      success: (res) => {
        if (res.data.length > 0) {
          const userData = res.data[0];
          this.setData({
            'userInfo.avatarUrl': userData.avatarUrl || this.data.userInfo.avatarUrl,
            // 核心：优先使用数据库中自定义昵称，而非微信原始昵称
            'userInfo.nickName': userData.nickname || '未设置昵称'
          });
        }
      }
    });
  },

  // 加载完整个人资料（含小区、电话、期望置换）
  loadUserDetail() {
    const openid = wx.getStorageSync('openid');
    if (!openid) return;

    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    db.collection('user').where({
      _openid: openid
    }).get({
      forceRefresh: true, // 强制刷新，不读缓存
      success: (res) => {
        if (res.data.length > 0) {
          const userDetail = res.data[0];
          this.setData({ 
            userDetail: userDetail,
            // 同步更新昵称显示
            'userInfo.nickName': userDetail.nickname?.trim() || this.data.userInfo.nickName || '未设置昵称'
          });
          wx.setStorageSync('community', userDetail.community || '');
        } else {
          this.setData({ userDetail: {} });
        }
      },
      fail: (err) => {
        console.error('加载个人信息失败：', err);
        wx.showToast({ title: '加载个人信息失败', icon: 'none' });
      }
    });
  },

  // 加载我的发布列表
  loadMyGoods() {
    const openid = wx.getStorageSync('openid');
    if (!openid) return;

    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    db.collection('goods').where({
      _openid: openid
    }).orderBy('createTime', 'desc').get({
      success: (res) => {
        this.setData({ myGoodsList: res.data });
      },
      fail: () => {
        wx.showToast({ title: '加载发布记录失败', icon: 'none' });
      }
    });
  },

  // 新增：加载我的收藏列表（关联collection和goods集合）
  loadMyCollection() {
    const openid = wx.getStorageSync('openid');
    if (!openid) return;

    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
    // 1. 先查询当前用户的收藏记录
    db.collection('collection')
      .where({ _openid: openid })
      .orderBy('createTime', 'desc')
      .get({
        success: (collectRes) => {
          if (collectRes.data.length === 0) {
            this.setData({ myCollectionList: [] });
            return;
          }

          // 2. 提取收藏的物品ID列表
          const goodsIds = collectRes.data.map(item => item.goodsId);
          // 3. 查询这些物品的完整信息
          db.collection('goods')
            .where({
              _id: db.command.in(goodsIds) // 批量查询
            })
            .get({
              success: (goodsRes) => {
                // 4. 合并收藏时间和物品信息
                const collectionList = goodsRes.data.map(goods => {
                  const collectItem = collectRes.data.find(item => item.goodsId === goods._id);
                  // 格式化收藏时间（简化显示）
                  const collectTime = collectItem.createTime 
                    ? new Date(collectItem.createTime).toLocaleDateString() 
                    : '未知时间';
                  return {
                    ...goods,
                    goodsId: goods._id, // 兼容跳转参数
                    collectTime: collectTime // 新增收藏时间字段
                  };
                });
                this.setData({ myCollectionList: collectionList });
              },
              fail: () => {
                wx.showToast({ title: '加载收藏物品失败', icon: 'none' });
                this.setData({ myCollectionList: [] });
              }
            });
        },
        fail: () => {
          wx.showToast({ title: '加载收藏记录失败', icon: 'none' });
          this.setData({ myCollectionList: [] });
        }
      });
  },

  // 微信快捷登录（核心修复：非首次登录不覆盖昵称 + 登录后返回详情页）
  wxLogin() {
    if (!this.data.canIUseGetUserProfile) {
      wx.showToast({ title: '当前微信版本过低，无法登录', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '登录中...' });

    // 1. 获取微信用户信息授权
    wx.getUserProfile({
      desc: '用于完善个人资料和登录验证',
      success: (userRes) => {
        const { nickName: wxNickName, avatarUrl: wxAvatarUrl } = userRes.userInfo;
        
        // 2. 调用云函数获取openid
        wx.cloud.callFunction({
          name: 'login',
          data: {}
        }).then(res => {
          wx.hideLoading();
          const openid = res.result?.openid || res.result?.data?.openid;
          
          if (!openid) {
            wx.showToast({ title: '登录失败，请重试', icon: 'none' });
            return;
          }

          // 3. 保存openid到本地
          wx.setStorageSync('openid', openid);
          
          // 4. 检查是否首次登录
          const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
          db.collection('user').where({ _openid: openid }).get({
            success: (dbRes) => {
              if (dbRes.data.length === 0) {
                // 首次登录：用微信昵称初始化
                db.collection('user').add({
                  data: {
                    _openid: openid,
                    nickname: wxNickName, // 首次登录才初始化微信昵称
                    avatarUrl: wxAvatarUrl,
                    createTime: db.serverDate(),
                    updateTime: db.serverDate()
                  },
                  success: () => {
                    wx.showToast({ title: '首次登录成功，请完善信息' });
                    wx.navigateTo({ url: '/pages/userInfoEdit/userInfoEdit' });
                    this.checkLogin(); // 刷新登录状态
                  },
                  fail: (err) => {
                    console.error('创建用户记录失败：', err);
                    wx.showToast({ title: '登录异常，请重试', icon: 'none' });
                  }
                });
              } else {
                // 非首次登录：仅更新头像，不覆盖自定义昵称！！！
                db.collection('user').doc(dbRes.data[0]._id).update({
                  data: {
                    avatarUrl: wxAvatarUrl, // 仅更新头像（可选）
                    updateTime: db.serverDate()
                    // 注释掉nickname，避免覆盖用户自定义昵称
                    // nickname: wxNickName 
                  },
                  success: () => {
                    wx.showToast({ title: '登录成功' });
                    this.checkLogin(); // 刷新登录状态

                    // 【新增核心逻辑】如果是从详情页跳转来的，登录后返回详情页
                    if (this.data.loginFromDetail && this.data.goodsId) {
                      setTimeout(() => {
                        wx.navigateTo({
                          url: `/pages/detail/detail?id=${this.data.goodsId}`
                        });
                        // 清空标记，避免重复跳转
                        this.setData({
                          loginFromDetail: false,
                          goodsId: ''
                        });
                      }, 1000);
                    }
                  },
                  fail: (err) => {
                    console.error('更新用户头像失败：', err);
                  }
                });
              }
            },
            fail: (err) => {
              console.error('查询用户记录失败：', err);
              wx.showToast({ title: '登录异常，请重试', icon: 'none' });
            }
          });
        }).catch(err => {
          wx.hideLoading();
          console.error('调用登录云函数失败：', err);
          wx.showToast({ title: '登录失败，请检查网络', icon: 'none' });
        });
      },
      fail: (err) => {
        wx.hideLoading();
        // 用户拒绝授权
        if (err.errMsg.includes('auth deny')) {
          wx.showToast({ title: '需要授权用户信息才能登录', icon: 'none' });
        } else {
          wx.showToast({ title: '授权失败，请重试', icon: 'none' });
        }
      }
    });
  },

  // 编辑个人资料
  editUserInfo() {
    const userDetailStr = encodeURIComponent(JSON.stringify(this.data.userDetail || {}));
    wx.navigateTo({
      url: `/pages/userInfoEdit/userInfoEdit?userDetail=${userDetailStr}`
    });
  },

  // 退出登录
  logout() {
    wx.showModal({
      title: '确认退出',
      content: '是否退出当前账号？退出后需重新登录',
      success: (res) => {
        if (res.confirm) {
          // 清空本地缓存
          wx.removeStorageSync('openid');
          wx.removeStorageSync('userInfo');
          wx.removeStorageSync('community');
          // 重置页面数据
          this.setData({
            isLogin: false,
            userInfo: {
              nickName: '未设置昵称',
              avatarUrl: 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0'
            },
            userDetail: {},
            myGoodsList: [],
            myCollectionList: [], // 新增：清空收藏列表
            loginFromDetail: false, // 清空标记
            goodsId: ''
          });
          wx.showToast({ title: '已退出登录', icon: 'success' });
        }
      }
    });
  },

  // 跳转物品详情页
  goDetail(e) {
    const goodsId = e.currentTarget.dataset.id;
    if (!goodsId) {
      wx.showToast({ title: '物品ID不存在', icon: 'none' });
      return;
    }
    wx.navigateTo({ url: `/pages/detail/detail?id=${goodsId}` });
  },

  // 供编辑页调用的刷新方法
  refreshUserDetail() {
    this.loadUserDetail();
  }
});