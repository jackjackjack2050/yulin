Page({
  data: {
    canIUseGetUserProfile: true,
    backFrom: '', // 新增：记录来源页面（如detail）
    goodsId: ''   // 新增：记录来源详情页的物品ID
  },

  onLoad() {
    // 检测是否支持wx.getUserProfile
    if (wx.getUserProfile) {
      this.setData({ canIUseGetUserProfile: true });
    } else {
      this.setData({ canIUseGetUserProfile: false });
      wx.showToast({ title: '当前微信版本过低，无法使用该功能', icon: 'none' });
    }

    // 【新增核心逻辑】接收从详情页传递的来源参数
    const eventChannel = this.getOpenerEventChannel();
    if (eventChannel) {
      eventChannel.on('loginBack', (data) => {
        this.setData({
          backFrom: data.from || '', // 来源页面（如detail）
          goodsId: data.goodsId || '' // 详情页的物品ID
        });
      });
    }
  },

  // 新增：返回上一页（适配登录页顶部返回按钮）
  navigateBack() {
    wx.navigateBack({
      delta: 1 // 返回上一级页面
    });
  },

  // 微信登录+授权获取用户信息
  wxLogin() {
    wx.showLoading({ title: '登录中...' });

    // 1. 获取微信用户信息授权
    wx.getUserProfile({
      desc: '用于完善个人资料和登录验证',
      success: (userRes) => {
        const { nickName, avatarUrl } = userRes.userInfo;
        
        // 2. 调用云函数获取openid
        wx.cloud.callFunction({
          name: 'login',
          data: {}
        }).then(res => {
          wx.hideLoading();
          const openid = res.result?.openid || res.result?.data?.openid;
          
          if (!openid) {
            wx.showToast({ title: '登录失败，请重试', icon: 'none' });
            return;
          }

          // 3. 保存openid到本地
          wx.setStorageSync('openid', openid);
          
          // 4. 检查是否首次登录
          const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });
          db.collection('user').where({ _openid: openid }).get({
            success: (dbRes) => {
              if (dbRes.data.length === 0) {
                // 首次登录：创建用户记录并引导完善信息
                db.collection('user').add({
                  data: {
                    _openid: openid,
                    nickname: nickName,
                    avatarUrl: avatarUrl,
                    createTime: db.serverDate(),
                    updateTime: db.serverDate()
                  },
                  success: () => {
                    wx.showToast({ title: '首次登录成功，请完善信息' });
                    // 跳转至完善信息页面
                    wx.navigateTo({ url: '/pages/userInfoEdit/userInfoEdit' });
                  },
                  fail: (err) => {
                    console.error('创建用户记录失败：', err);
                    wx.showToast({ title: '登录异常，请重试', icon: 'none' });
                  }
                });
              } else {
                // 非首次登录：更新头像昵称并返回
                db.collection('user').doc(dbRes.data[0]._id).update({
                  data: {
                    nickname: nickName,
                    avatarUrl: avatarUrl,
                    updateTime: db.serverDate()
                  }
                });
                wx.showToast({ title: '登录成功' });

                // 【新增核心逻辑】根据来源页面跳转（优先返回详情页）
                setTimeout(() => {
                  const { backFrom, goodsId } = this.data;
                  if (backFrom === 'detail' && goodsId) {
                    // 从详情页登录：返回原详情页
                    wx.navigateTo({
                      url: `/pages/detail/detail?id=${goodsId}`
                    });
                  } else {
                    // 其他场景：返回上一页（如我的页面）
                    wx.navigateBack();
                  }
                }, 1000);
              }
            },
            fail: (err) => {
              console.error('查询用户记录失败：', err);
              wx.showToast({ title: '登录异常，请重试', icon: 'none' });
            }
          });
        }).catch(err => {
          wx.hideLoading();
          console.error('调用登录云函数失败：', err);
          wx.showToast({ title: '登录失败，请检查网络', icon: 'none' });
        });
      },
      fail: (err) => {
        wx.hideLoading();
        // 用户拒绝授权
        if (err.errMsg.includes('auth deny')) {
          wx.showToast({ title: '需要授权用户信息才能登录', icon: 'none' });
        } else {
          wx.showToast({ title: '授权失败，请重试', icon: 'none' });
        }
      }
    });
  }
});