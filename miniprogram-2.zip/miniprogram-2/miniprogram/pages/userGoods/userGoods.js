Page({
  data: {
    goodsList: [],       // 该发布者的物品列表
    publisherOpenid: '', // 发布者openid
    publisherName: '',   // 发布者昵称
    isLoading: true      // 加载状态
  },

  onLoad(options) {
    // 接收从详情页传递的参数
    if (options.publisherOpenid) {
      this.setData({
        publisherOpenid: options.publisherOpenid,
        publisherName: options.publisherName || '该用户'
      });
      // 加载该发布者的所有物品
      this.loadUserGoods();
    } else {
      wx.showToast({ title: '参数错误', icon: 'none' });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    }
  },

  // 加载该发布者的所有物品
  loadUserGoods() {
    this.setData({ isLoading: true });
    // 替换为你的云环境ID（和你现有代码保持一致）
    const db = wx.cloud.database({ env: 'cloud1-9ghg0fkfd7d6009d' });

    db.collection('goods')
      .where({
        _openid: this.data.publisherOpenid // 按发布者openid筛选
      })
      .orderBy('createTime', 'desc') // 按发布时间倒序
      .get({
        success: (res) => {
          this.setData({
            goodsList: res.data,
            isLoading: false
          });
        },
        fail: () => {
          wx.showToast({ title: '加载失败，请重试', icon: 'none' });
          this.setData({ isLoading: false });
        }
      });
  },

  // 跳转物品详情页（和你现有跳转逻辑一致）
  goDetail(e) {
    const goodsId = e.currentTarget.dataset.id;
    if (!goodsId) return;
    wx.navigateTo({ url: `/pages/detail/detail?id=${goodsId}` });
  }
});