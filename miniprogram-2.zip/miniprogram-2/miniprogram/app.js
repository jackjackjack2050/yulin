App({
  onLaunch() {
    // 全局初始化云环境
    if (wx.cloud) {
      wx.cloud.init({
        env: 'cloud1-9ghg0fkfd7d6009d', // 你的云环境ID
        traceUser: true
      });
      console.log('全局云环境初始化成功：', 'cloud1-9ghg0fkfd7d6009d');
    } else {
      console.error('当前微信版本不支持云开发，请升级微信');
    }
  }
});